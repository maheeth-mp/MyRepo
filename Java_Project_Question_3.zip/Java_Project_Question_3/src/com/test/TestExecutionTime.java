package com.test;
import java.util.Arrays;

import com.interceptor.TimeInterceptor;
import com.sample.test.classes.Calculate;
import com.sample.test.classes.CalculateImpl;
import com.sample.test.classes.Sort;
import com.sample.test.classes.SortImpl;


public class TestExecutionTime {

	public static void main(String[] args) {
		
		System.out.println("Sample output for measuring time consumed for any independent method in other classes");
		System.out.println("-------------------------------------------------------------------------------------");
		
		// Test for Calculator 
		Calculate calculate = (Calculate) TimeInterceptor.newInstance(new CalculateImpl(2,1));
		calculate.sum();
		calculate.diff();
	
		// Test for Sort
		Sort sort = (Sort) TimeInterceptor.newInstance(new SortImpl(Arrays.asList("abc","klm","xyz","pqr")));
		sort.asc();
		sort.desc();
	}

}
