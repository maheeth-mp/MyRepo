package com.interceptor;

import java.lang.reflect.Method;

/**
 * Invocation handler implementation to calculate the execution time of each method in a class.
 *
 */
public class TimeInterceptor implements java.lang.reflect.InvocationHandler {

	private Object obj;

	private TimeInterceptor(Object obj) {
		this.obj = obj;
	}

	public Object invoke(Object proxy, Method m, Object[] args)
			throws Throwable {
		Object result;
		try {			
			// Start time prior to invoke
			long start = System.nanoTime();
			// Invoke method using reflection api
			result = m.invoke(obj, args);
			// End time after invoke
			long end = System.nanoTime();			
			long duration = (end - start);			
			System.out.println(String.format("%s.%s took %d ns", obj.getClass(), m.getName(),
					duration));
			
		} catch (Exception e) {
			throw new RuntimeException("Exception: " + e.getMessage());
		}
		
		return result;
	}
	
	// Helper method to initialize the TimeInterceptor with an object to be monitored.
	public static Object newInstance(Object obj) {
		return java.lang.reflect.Proxy.newProxyInstance(obj.getClass()
				.getClassLoader(), obj.getClass().getInterfaces(),
				new TimeInterceptor(obj));
	}
}
