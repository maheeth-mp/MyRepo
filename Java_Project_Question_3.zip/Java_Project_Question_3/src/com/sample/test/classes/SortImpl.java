package com.sample.test.classes;

import java.util.Collections;

import java.util.Comparator;
import java.util.List;


/**
 * Implementation for Sort Interface
 * 
 */
public class SortImpl implements Sort {

	List<String> list;

	public SortImpl(List<String> list) {
		this.list = list;
	}

	@Override
	public List<String> asc() {
		Collections.sort(list, new Comparator<String>() {
			@Override
			public int compare(String a, String b) {
				return a.compareTo(b);
			}
		});
		return list;
	}

	@Override
	public List<String> desc() {
		Collections.sort(list, new Comparator<String>() {
			@Override
			public int compare(String a, String b) {
				return b.compareTo(a);
			}
		});
		return list;
	}

}
