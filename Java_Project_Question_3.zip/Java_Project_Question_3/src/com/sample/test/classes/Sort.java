package com.sample.test.classes;

import java.util.List;

/**
 * Test Interface 
 *
 */
public interface Sort {
	
	public List<String> asc();
	
	public List<String> desc();
}
