package com.sample.test.classes;

/**
 * Implementation for Calculator Interface
 *
 */
public class CalculateImpl implements Calculate{
	
	int a,b;
	
	public CalculateImpl(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public int sum() {
		return (a + b);
	}
	
	public int diff() {
		return (a - b);
	}	 
}
