package com.sample.test.classes;

/**
 * Test Interface 
 *
 */
public interface Calculate {

	public int sum();
	
	public int diff();
}
