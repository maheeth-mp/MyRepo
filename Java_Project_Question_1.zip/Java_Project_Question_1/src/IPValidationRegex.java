import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPValidationRegex {

	private static Matcher matcher;
	
	// The below regular expression pattern checks if the following IP address is a string in the form "A.B.C.D", where the value of A, B, C, and D may range
	// from 0 to 255. Leading zeros are allowed and the length of A, B, C, or D can't be greater than 3
	private static final String IPADDRESS_PATTERN = "(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])";
	
	private static Pattern pattern = Pattern.compile(IPADDRESS_PATTERN);

	/**
	 * Validate IP address with regular expression
	 * 
	 * @param ip IP address for validation
	 *            
	 * @return true if IP address is valid, false if IP address is invalid
	 */
	private static boolean validate(final String ip) {
		matcher = pattern.matcher(ip);
		return matcher.matches();
	}

	public static void main(String[] args) throws URISyntaxException, IOException  {
		try {
			URL path = ClassLoader.getSystemResource("Test_data.txt");
			File f = new File(path.toURI());
			BufferedReader b = new BufferedReader(new FileReader(f));
			String readIP = "";
			boolean isvalid;
			System.out.println("List of Invalid IP Address(es)");
			System.out.println("------------------------------");
			while ((readIP = b.readLine()) != null) {
				isvalid = validate(readIP.toString());
				if (!isvalid) {
					System.out.println(readIP);
				}
			}
			b.close();
		} 
		catch (URISyntaxException e) {
			e.printStackTrace();
		}	
		catch (IOException e) {
			e.printStackTrace();
		}		
	}
}