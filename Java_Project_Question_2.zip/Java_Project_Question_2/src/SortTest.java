import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;

public class SortTest {

	public static void main(String[] args) {
		List<Student> ls = new ArrayList<Student>();
		// Sample Input
		ls.add(new Student(33, "Tina", 3.68));
		ls.add(new Student(85, "Louis", 3.85));
		ls.add(new Student(56, "Samil", 3.75));
		ls.add(new Student(19, "Samar", 3.75));
		ls.add(new Student(22, "Lorry", 3.76));
		ls.add(new Student(20, "Lorry", 3.76));

		// Sort by GPA descending, FirstName by alphabetical order | and then by ID in ascending order
		Collections.sort(ls, new Comparator<Student>() {
			@Override
			public int compare(final Student s1, final Student s2) {
				int c;
				c = Double.valueOf(s2.getGpa()).compareTo(Double.valueOf(s1.getGpa()));
				if (c == 0)
					c = (s1.getFirstName().toUpperCase()).compareTo((s2.getFirstName().toUpperCase()));
				if (c == 0)
					c = s1.getId() - s2.getId();
				return c;
			}
		});
		System.out.println("Output");
		System.out.println("------");
		System.out.println("Sorted by GPA descending | FirstName by alphabetical order if GPA is same | and then by ID in ascending order if FirstName is identical");
		System.out.println("GPA  " + "FName" + " Id");
		System.out.println("---  " + "-----" + " --");
		for (ListIterator<Student> iter = ls.listIterator(); iter.hasNext();) {
			Student st = iter.next();
			System.out.println(st.getGpa() + " " + st.getFirstName() + " " + st.getId());
		}

	}

}
